const { ApplicationCommandType } = require("discord.js");
const { owner } = require("../../config.json");

module.exports = {
  name: "painel_cloner",
  description: "[🤖] Envie o painel de clonagem.",
  type: ApplicationCommandType.ChatInput,

  run: async (client, interaction) => {
    if (interaction.user.id !== owner) {
      return interaction.reply({
        content: "❌ Você não tem permissão para usar este comando.",
        ephemeral: true,
      });
    }

    try {
      await interaction.reply({
        content: "✅ Sucesso",
        ephemeral: true,
      });

      const BotFoto = client.user.displayAvatarURL({ format: "png", dynamic: true, size: 1024 });

      await interaction.channel.send({
        content: "",
        components: [
          {
            type: 17,
            components: [
              {
                type: 9,
                accessory: {
                  type: 11,
                  media: {
                    url: BotFoto,
                  },
                  description: null,
                  spoiler: false,
                },
                components: [
                  {
                    type: 10,
                    content: `## Painel de Clonagem\n> Olá, Membro! Utilize os botões abaixo para acessar o painel de clonagem.`,
                  },
                  {
                    type: 10,
                    content: "## Ensinamentos\n • Necessário ID do servidor que será clonado e do servidor que irá receber.\n • A conta precisa estar presente em ambos os servidores.\n • O token da conta será exigido!",
                  },
                ],
              },
              {
                type: 14,
                spacing: 1,
                divider: true,
              },
              {
                type: 1,
                components: [
                  {
                    type: 2,
                    custom_id: "panel_cloner",
                    label: "Clonar Servidor",
                    style: 2,
                    emoji: {
                      id: "1357524823302996090",
                    },
                  },
                  {
                    type: 2,
                    custom_id: "clonersite",
                    label: "Clonar Site",
                    style: 2,
                    emoji: {
                      id: "1357524823302996090",
                    },
                  },
                ],
              },
              {
                type: 10,
                content: "-# Todos os copyrights para [!zKingzs](https://discord.gg/9mvazamento)",
              },
            ],
          },
        ],
        flags: 32768,
      });

    } catch (error) {
      console.error("Erro:", error);
      if (!interaction.replied) {
        await interaction.reply({
          content: "❌ Vish deu erro aqui pae",
          ephemeral: true,
        });
      }
    }
  }, 
};
